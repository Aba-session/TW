//
//  CategoryEntity.swift
//  TW
//
//  Created by aba on 23.05.2021.
//

import Foundation
import CoreData

class CategoryEntity: NSManagedObject {
    
}
